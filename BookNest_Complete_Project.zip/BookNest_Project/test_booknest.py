import unittest
from booknest import LibraryDB, completion_percentage, validate_book

class BookNestTests(unittest.TestCase):
    def setUp(self):
        self.db = LibraryDB(':memory:')

    def tearDown(self):
        self.db.close()

    def test_percentage(self):
        self.assertEqual(completion_percentage(2, 5), 40.0)
        self.assertEqual(completion_percentage(0, 0), 0.0)

    def test_add_update_delete(self):
        self.db.add('Dune', 'Frank Herbert', 'Sci-fi', 500, 0, 'To Read')
        self.assertEqual(self.db.summary()['total'], 1)
        book_id = self.db.all()[0]['id']
        self.db.update(book_id, 'Dune', 'Frank Herbert', 'Sci-fi', 500, 200, 'Reading')
        self.assertEqual(self.db.summary()['reading'], 1)
        self.db.delete(book_id)
        self.assertEqual(self.db.summary()['total'], 0)

    def test_invalid_pages(self):
        with self.assertRaises(ValueError):
            validate_book('Dune', 'Frank Herbert', 100, 101, 'Reading')
        with self.assertRaises(ValueError):
            validate_book('Dune', 'Frank Herbert', 100, 20, 'Completed')

    def test_search_filter(self):
        self.db.add('Dune', 'Frank Herbert', 'Sci-fi', 500, 0, 'To Read')
        self.db.add('Emma', 'Jane Austen', 'Classic', 300, 300, 'Completed')
        self.assertEqual(len(self.db.all('Dune')), 1)
        self.assertEqual(len(self.db.all(status='Completed')), 1)

if __name__ == '__main__':
    unittest.main()
